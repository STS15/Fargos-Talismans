package com.sts15.fargos.init;

import com.sts15.fargos.Fargos;
import com.sts15.fargos.api.crafting.ITableRecipe;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.crafting.RecipeType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModRecipeTypes {
    public static final DeferredRegister<RecipeType<?>> REGISTRY = DeferredRegister.create(Registries.RECIPE_TYPE, Fargos.MODID);

    public static final DeferredHolder<RecipeType<?>, RecipeType<ITableRecipe>> TABLE = REGISTRY.register("table", () -> RecipeType.simple(ResourceLocation.fromNamespaceAndPath(Fargos.MODID,"crucible_of_the_cosmos")));
}