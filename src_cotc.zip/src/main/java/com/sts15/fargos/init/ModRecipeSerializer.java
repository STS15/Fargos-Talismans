package com.sts15.fargos.init;

import com.sts15.fargos.Fargos;
import com.sts15.fargos.crafting.recipe.CrucibleOfTheCosmosRecipeSerializer;
import com.sts15.fargos.crafting.recipe.CrucibleOfTheCosmosRecipeType;
import com.sts15.fargos.crafting.recipe.ShapedTableRecipe;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModRecipeSerializer {
    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS = DeferredRegister.create(Registries.RECIPE_SERIALIZER, Fargos.MODID);
    public static final Supplier<RecipeSerializer<?>> CRUCIBLE_RECIPE_SERIALIZER = SERIALIZERS.register("crucibleofthecosmos", () -> CrucibleOfTheCosmosRecipeSerializer.INSTANCE);

    public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = DeferredRegister.create(Registries.RECIPE_TYPE, Fargos.MODID);
    public static final Supplier<RecipeType<ShapedTableRecipe>> CRUCIBLE_RECIPE_TYPE = RECIPE_TYPES.register("crucibleofthecosmos", () -> CrucibleOfTheCosmosRecipeType.INSTANCE);

}
