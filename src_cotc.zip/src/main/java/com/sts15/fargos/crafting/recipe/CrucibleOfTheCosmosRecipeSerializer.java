package com.sts15.fargos.crafting.recipe;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.*;

public class CrucibleOfTheCosmosRecipeSerializer implements RecipeSerializer<CrucibleOfTheCosmosRecipe> {
    public static final CrucibleOfTheCosmosRecipeSerializer INSTANCE = new CrucibleOfTheCosmosRecipeSerializer();

    public static final MapCodec<CrucibleOfTheCosmosRecipe> CODEC = RecordCodecBuilder.mapCodec(builder ->
            builder.group(
                    ShapedRecipePatternCodecs.MAP_CODEC.forGetter(recipe -> recipe.pattern),
                    ItemStack.STRICT_CODEC.fieldOf("result").forGetter(recipe -> recipe.result)
            ).apply(builder, (pattern, result) -> new CrucibleOfTheCosmosRecipe(null, pattern, result))
    );

    public static final StreamCodec<RegistryFriendlyByteBuf, CrucibleOfTheCosmosRecipe> STREAM_CODEC = StreamCodec.of(
            CrucibleOfTheCosmosRecipeSerializer::toNetwork,
            CrucibleOfTheCosmosRecipeSerializer::fromNetwork
    );

    @Override
    public MapCodec<CrucibleOfTheCosmosRecipe> codec() {
        return CODEC;
    }

    @Override
    public StreamCodec<RegistryFriendlyByteBuf, CrucibleOfTheCosmosRecipe> streamCodec() {
        return STREAM_CODEC;
    }

    @Override
    public CrucibleOfTheCosmosRecipe fromJson(ResourceLocation recipeId, JsonObject json) {
        var patternResult = ShapedRecipePatternCodecs.MAP_CODEC.decode(JsonOps.INSTANCE, json);
        if (patternResult.error().isPresent()) {
            throw new JsonParseException("Error parsing pattern: " + patternResult.error().get().message());
        }
        ShapedRecipePattern pattern = patternResult.result().orElseThrow();
        ItemStack result = ShapedRecipe.itemStackFromJson(GsonHelper.getAsJsonObject(json, "result"));
        return new CrucibleOfTheCosmosRecipe(recipeId, pattern, result);
    }

    @Override
    public CrucibleOfTheCosmosRecipe fromNetwork(ResourceLocation recipeId, FriendlyByteBuf buffer) {
        var registryBuffer = new RegistryFriendlyByteBuf(buffer);
        ShapedRecipePattern pattern = ShapedRecipePattern.STREAM_CODEC.decode(registryBuffer);
        ItemStack result = ItemStack.STREAM_CODEC.decode(registryBuffer);
        return new CrucibleOfTheCosmosRecipe(recipeId, pattern, result);
    }

    @Override
    public void toNetwork(FriendlyByteBuf buffer, CrucibleOfTheCosmosRecipe recipe) {
        var registryBuffer = new RegistryFriendlyByteBuf(buffer);
        ShapedRecipePattern.STREAM_CODEC.encode(registryBuffer, recipe.pattern);
        ItemStack.STREAM_CODEC.encode(registryBuffer, recipe.result);
    }
}
