package com.sts15.fargos.crafting.recipe;

import net.minecraft.world.item.crafting.RecipeType;

public class CrucibleOfTheCosmosRecipeType implements RecipeType<ShapedTableRecipe> {
    public static final CrucibleOfTheCosmosRecipeType INSTANCE = new CrucibleOfTheCosmosRecipeType();

    private CrucibleOfTheCosmosRecipeType() {}
}
