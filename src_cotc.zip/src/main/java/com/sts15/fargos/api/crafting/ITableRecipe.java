package com.sts15.fargos.api.crafting;

import com.sts15.fargos.crafting.CrucibleCraftingInput;
import net.minecraft.world.item.crafting.Recipe;

/**
 * Used to represent an Crucible Crafting Table recipe for the recipe type
 */
public interface ITableRecipe extends Recipe<CrucibleCraftingInput> {
    int getTier();
    boolean hasRequiredTier();
}